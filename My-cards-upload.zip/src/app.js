import { CONFIG } from './config.js';
import { createBrain, evaluateBrain, forward, isValidBrain, trainEpoch, TRAINING_DATA } from './brain.js';
import { downloadBrain, loadLocalBrain, readBrainFile, saveLocalBrain } from './storage.js';

const byId = id => document.getElementById(id);
const elements = {
  status: byId('status'), accuracy: byId('accuracy'), loss: byId('loss'), epochsDone: byId('epochsDone'),
  memoryStatus: byId('memoryStatus'), epochs: byId('epochs'), epochValue: byId('epochValue'),
  learningRate: byId('learningRate'), learningRateValue: byId('learningRateValue'),
  trainButton: byId('trainButton'), resetButton: byId('resetButton'), progressBar: byId('progressBar'),
  progressText: byId('progressText'), progressPercent: byId('progressPercent'), chart: byId('lossChart'),
  sampleRows: byId('sampleRows'), inputA: byId('inputA'), inputB: byId('inputB'), prediction: byId('prediction'),
  confidence: byId('confidence'), probabilityBar: byId('probabilityBar'), probabilityText: byId('probabilityText'),
  exportButton: byId('exportButton'), importButton: byId('importButton'), importFile: byId('importFile'),
  localSaveText: byId('localSaveText'), cloudIndicator: byId('cloudIndicator'), cloudConnectButton: byId('cloudConnectButton'),
  cloudSaveButton: byId('cloudSaveButton'), cloudLoadButton: byId('cloudLoadButton'), cloudStatus: byId('cloudStatus')
};

let brain = loadLocalBrain() || createBrain();
let active = false;
let loopRunning = false;
let loopRunId = 0;
let remainingEpochs = 0;
let requestedEpochs = 0;
let cloudModulePromise = null;
let cloudConnected = false;
let lastMetrics = evaluateBrain(brain);

function setStatus(text, color = 'mint') {
  elements.status.textContent = text;
  elements.status.style.color = color === 'red' ? 'var(--red)' : color === 'gold' ? 'var(--gold)' : 'var(--mint)';
}

function formatNumber(value) {
  return Number(value).toLocaleString('ru-RU');
}

function saveLocal(reason = 'Автосохранение выполнено') {
  const result = saveLocalBrain(brain);
  if (result.ok) {
    elements.memoryStatus.textContent = 'Локально';
    elements.localSaveText.textContent = `${reason} · ${result.savedAt.toLocaleTimeString('ru-RU')}`;
  } else {
    elements.memoryStatus.textContent = 'Ошибка';
    elements.localSaveText.textContent = `Не удалось сохранить в браузере: ${result.error?.message || 'неизвестная ошибка'}`;
  }
}

function drawChart() {
  const canvas = elements.chart;
  const context = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  context.clearRect(0, 0, width, height);
  context.strokeStyle = '#26394b';
  context.lineWidth = 1;
  for (let line = 1; line <= 4; line += 1) {
    const y = (height / 5) * line;
    context.beginPath(); context.moveTo(0, y); context.lineTo(width, y); context.stroke();
  }
  const values = brain.lossHistory || [];
  if (values.length < 2) return;
  const max = Math.max(1, ...values);
  const min = Math.min(0, ...values);
  const range = Math.max(0.000001, max - min);
  context.beginPath();
  values.forEach((value, index) => {
    const x = 14 + ((width - 28) * index) / (values.length - 1);
    const y = height - 14 - ((value - min) / range) * (height - 28);
    if (index === 0) context.moveTo(x, y); else context.lineTo(x, y);
  });
  context.strokeStyle = '#82e6c5';
  context.lineWidth = 3;
  context.lineJoin = 'round';
  context.lineCap = 'round';
  context.stroke();
}

function renderSamples(metrics) {
  elements.sampleRows.innerHTML = metrics.rows.map(row => {
    const state = row.correct ? '<span class="state-good">✓ верно</span>' : '<span class="state-bad">× ошибка</span>';
    const answer = brain.epoch ? `${row.prediction} · ${(row.probability * 100).toFixed(1)}%` : '—';
    return `<tr><td>${row.input[0]}</td><td>${row.input[1]}</td><td>${row.target}</td><td>${answer}</td><td>${brain.epoch ? state : '<span class="state-pending">ожидание</span>'}</td></tr>`;
  }).join('');
}

function renderPrediction() {
  const input = [Number(elements.inputA.value), Number(elements.inputB.value)];
  const probability = forward(brain, input).probability;
  const prediction = probability >= 0.5 ? 1 : 0;
  elements.prediction.textContent = brain.epoch ? String(prediction) : '—';
  elements.confidence.textContent = brain.epoch ? `${(Math.max(probability, 1 - probability) * 100).toFixed(1)}%` : 'Нет данных';
  elements.probabilityBar.style.width = `${probability * 100}%`;
  elements.probabilityText.textContent = `Вероятность ответа 1: ${(probability * 100).toFixed(1)}%`;
}

function render() {
  lastMetrics = evaluateBrain(brain);
  elements.accuracy.textContent = `${Math.round(lastMetrics.accuracy * 100)}%`;
  elements.loss.textContent = lastMetrics.loss.toFixed(4);
  elements.epochsDone.textContent = formatNumber(brain.epoch);
  renderSamples(lastMetrics);
  renderPrediction();
  drawChart();
}

function updateProgress() {
  const finished = requestedEpochs - remainingEpochs;
  const percent = requestedEpochs ? Math.round((finished / requestedEpochs) * 100) : 0;
  elements.progressBar.style.width = `${percent}%`;
  elements.progressPercent.textContent = `${percent}%`;
  elements.progressText.textContent = active
    ? `Обучение: осталось ${formatNumber(remainingEpochs)} эпох`
    : remainingEpochs > 0 ? `Пауза · осталось ${formatNumber(remainingEpochs)} эпох` : 'Готова к запуску';
}

function updateControls() {
  elements.trainButton.textContent = active ? 'Ⅱ Пауза' : remainingEpochs > 0 ? '▶ Продолжить' : '▶ Начать обучение';
  elements.resetButton.disabled = active;
  elements.epochs.disabled = active || remainingEpochs > 0;
  elements.learningRate.disabled = active;
  setStatus(active ? 'ОБУЧАЕТСЯ' : remainingEpochs > 0 ? 'ПАУЗА' : 'ГОТОВА');
}

async function trainingLoop(runId) {
  while (active && remainingEpochs > 0 && runId === loopRunId) {
    const count = Math.min(CONFIG.epochsPerFrame, remainingEpochs);
    const rate = Number(elements.learningRate.value);
    for (let index = 0; index < count; index += 1) {
      lastMetrics = trainEpoch(brain, rate);
      if (brain.epoch % 20 === 0) {
        brain.lossHistory.push(lastMetrics.loss);
        if (brain.lossHistory.length > CONFIG.chartHistoryLimit) brain.lossHistory.shift();
      }
    }
    remainingEpochs -= count;
    render();
    updateProgress();
    if (brain.epoch % CONFIG.saveEveryEpochs === 0) saveLocal();
    await new Promise(resolve => requestAnimationFrame(resolve));
  }

  if (runId !== loopRunId) return;
  loopRunning = false;
  active = false;
  if (remainingEpochs === 0) {
    brain.lossHistory.push(evaluateBrain(brain).loss);
    saveLocal('Обученная модель сохранена');
    elements.progressBar.style.width = '100%';
    elements.progressPercent.textContent = '100%';
    elements.progressText.textContent = `Завершено · точность ${Math.round(lastMetrics.accuracy * 100)}%`;
    setStatus('ГОТОВА');
  } else {
    setStatus('ПАУЗА', 'gold');
  }
  updateControls();
  render();
}

function startOrPauseTraining() {
  if (active) {
    active = false;
    updateControls();
    updateProgress();
    return;
  }
  if (remainingEpochs <= 0) {
    requestedEpochs = Number(elements.epochs.value);
    remainingEpochs = requestedEpochs;
  }
  active = true;
  updateControls();
  updateProgress();
  if (!loopRunning) {
    loopRunning = true;
    const runId = ++loopRunId;
    trainingLoop(runId).catch(error => {
      if (runId !== loopRunId) return;
      loopRunning = false;
      active = false;
      setStatus('ОШИБКА', 'red');
      elements.progressText.textContent = `Ошибка обучения: ${error.message}`;
      updateControls();
      console.error(error);
    });
  }
}

function resetBrain() {
  loopRunId += 1;
  loopRunning = false;
  active = false;
  remainingEpochs = 0;
  requestedEpochs = 0;
  brain = createBrain();
  saveLocal('Новая модель сохранена');
  elements.progressBar.style.width = '0%';
  elements.progressPercent.textContent = '0%';
  elements.progressText.textContent = 'Готова к первому запуску';
  updateControls();
  render();
}

function getCloudModule() {
  if (!cloudModulePromise) cloudModulePromise = import('./supabase.js');
  return cloudModulePromise;
}

function cloudErrorMessage(error) {
  const message = String(error?.message || error || 'Неизвестная ошибка');
  if (/anonymous|anonymous sign.?in|disabled|not enabled/i.test(message)) {
    return 'Supabase подключён, но анонимный вход выключен. Включи Authentication → Sign In / Providers → Anonymous Sign-Ins и повтори.';
  }
  if (/Failed to fetch|NetworkError|fetch/i.test(message)) {
    return 'Не удалось связаться с Supabase или загрузить SDK. Проверь интернет и настройки проекта.';
  }
  return message;
}

async function connectCloud() {
  elements.cloudConnectButton.disabled = true;
  elements.cloudStatus.textContent = 'Подключаем Supabase…';
  try {
    const cloud = await getCloudModule();
    const user = await cloud.connectAnonymous();
    cloudConnected = true;
    elements.cloudIndicator.classList.add('connected');
    elements.cloudStatus.textContent = `Облако подключено · ID ${user.id.slice(0, 8)}…`;
  } catch (error) {
    cloudConnected = false;
    elements.cloudIndicator.classList.remove('connected');
    elements.cloudStatus.textContent = cloudErrorMessage(error);
    console.warn('Supabase connection:', error);
  } finally {
    elements.cloudConnectButton.disabled = false;
  }
}

async function saveCloud() {
  elements.cloudSaveButton.disabled = true;
  elements.cloudStatus.textContent = 'Сохраняем параметры модели в Supabase…';
  try {
    const cloud = await getCloudModule();
    const metrics = evaluateBrain(brain);
    const result = await cloud.saveBrainToCloud(brain, {
      accuracy: metrics.accuracy,
      loss: metrics.loss,
      epochs: brain.epoch
    });
    cloudConnected = true;
    elements.cloudIndicator.classList.add('connected');
    elements.cloudStatus.textContent = `Облачная копия сохранена · ${new Date(result.saved.updated_at).toLocaleString('ru-RU')}`;
  } catch (error) {
    elements.cloudStatus.textContent = cloudErrorMessage(error);
    console.warn('Supabase save:', error);
  } finally {
    elements.cloudSaveButton.disabled = false;
  }
}

async function loadCloud() {
  elements.cloudLoadButton.disabled = true;
  elements.cloudStatus.textContent = 'Ищем сохранённую модель…';
  try {
    const cloud = await getCloudModule();
    const record = await cloud.loadBrainFromCloud();
    if (!record) {
      elements.cloudStatus.textContent = 'В облаке пока нет сохранённой модели MiniBrain.';
      return;
    }
    if (!isValidBrain(record.weights)) throw new Error('Облачная запись содержит несовместимые веса модели.');
    loopRunId += 1;
    loopRunning = false;
    active = false;
    brain = record.weights;
    remainingEpochs = 0;
    requestedEpochs = 0;
    saveLocal('Облачная модель скопирована в браузер');
    elements.progressBar.style.width = '0%';
    elements.progressPercent.textContent = '0%';
    elements.progressText.textContent = 'Модель загружена из облака';
    cloudConnected = true;
    elements.cloudIndicator.classList.add('connected');
    elements.cloudStatus.textContent = `Загружено из облака · ${new Date(record.updated_at).toLocaleString('ru-RU')}`;
    updateControls();
    render();
  } catch (error) {
    elements.cloudStatus.textContent = cloudErrorMessage(error);
    console.warn('Supabase load:', error);
  } finally {
    elements.cloudLoadButton.disabled = false;
  }
}

function bindEvents() {
  elements.epochs.addEventListener('input', () => {
    elements.epochValue.textContent = formatNumber(elements.epochs.value);
  });
  elements.learningRate.addEventListener('input', () => {
    elements.learningRateValue.textContent = Number(elements.learningRate.value).toFixed(3);
  });
  elements.trainButton.addEventListener('click', startOrPauseTraining);
  elements.resetButton.addEventListener('click', resetBrain);
  elements.inputA.addEventListener('change', renderPrediction);
  elements.inputB.addEventListener('change', renderPrediction);
  elements.exportButton.addEventListener('click', () => downloadBrain(brain));
  elements.importButton.addEventListener('click', () => elements.importFile.click());
  elements.importFile.addEventListener('change', async event => {
    try {
      const imported = await readBrainFile(event.target.files?.[0]);
      loopRunId += 1;
      loopRunning = false;
      active = false;
      remainingEpochs = 0;
      requestedEpochs = 0;
      brain = imported;
      saveLocal('Импортированная модель сохранена');
      updateControls();
      render();
    } catch (error) {
      elements.localSaveText.textContent = `Импорт не выполнен: ${error.message}`;
    } finally {
      event.target.value = '';
    }
  });
  elements.cloudConnectButton.addEventListener('click', connectCloud);
  elements.cloudSaveButton.addEventListener('click', saveCloud);
  elements.cloudLoadButton.addEventListener('click', loadCloud);
}

function boot() {
  elements.epochs.value = String(CONFIG.defaultEpochs);
  elements.epochValue.textContent = formatNumber(CONFIG.defaultEpochs);
  elements.learningRate.value = String(CONFIG.defaultLearningRate);
  elements.learningRateValue.textContent = CONFIG.defaultLearningRate.toFixed(3);
  bindEvents();
  render();
  updateControls();
  if (loadLocalBrain()) elements.localSaveText.textContent = 'Найдена сохранённая модель в этом браузере.';
  else saveLocal('Создана начальная модель');
  const warning = byId('boot-warning');
  if (warning) warning.hidden = true;
  window.__MINIBRAIN_READY__ = true;
  console.info(`${CONFIG.appName} ${CONFIG.appVersion}: все локальные модули запущены.`);
}

try {
  boot();
} catch (error) {
  console.error('MiniBrain boot error:', error);
  const warning = byId('boot-warning');
  if (warning) {
    warning.hidden = false;
    warning.textContent = `MiniBrain не смог запуститься: ${error.message}. Проверь файлы src и открой консоль браузера для подробностей.`;
  }
  setStatus('ОШИБКА', 'red');
}
